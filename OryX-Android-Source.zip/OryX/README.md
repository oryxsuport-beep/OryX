# OryX — Android Music Player

Player Android em React + TypeScript + Vite + Capacitor, com tema escuro e identidade OryX (Ory branco, X vermelho).

## Funcionalidades incluídas

- Reprodução de URL HTTP(S) direta usando HTML5 Audio.
- Seleção e reprodução de arquivos de áudio locais pelo seletor de arquivos Android.
- Fila de reprodução em memória.
- Play/pause, faixa anterior/próxima, seek e volume.
- Estados `canplay`, `waiting`, `ended` e `error`.
- Busca de letras no LRCLIB (`/api/get`) e realce das linhas sincronizadas.
- Parser de timestamps LRC.
- Logo SVG em `public/oryx-logo.svg`.

## Requisitos

- Node.js 20 ou 22 (recomendado).
- npm.
- Android Studio recente com Android SDK instalado.
- JDK 21 (use o JDK embutido no Android Studio, se configurado).
- Para aparelho físico: depuração USB habilitada ou transferência do APK.

## Rodar no computador para testar

```bash
npm install
npm run dev
```

Abra o endereço que o Vite mostrar (normalmente `http://localhost:5173`).

## Gerar o projeto Android

Na raiz do projeto:

```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```

No Android Studio:
1. Aguarde a sincronização do Gradle.
2. Conecte um celular ou crie um emulador.
3. Para testar, clique em **Run**.
4. Para gerar APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O Android Studio exibirá o caminho do APK gerado. Normalmente fica em `android/app/build/outputs/apk/debug/app-debug.apk`.

Para atualizar o app depois de alterar o código web:

```bash
npm run build
npx cap sync android
```

### Gerar APK debug pelo terminal

Com Android SDK e variáveis de ambiente configuradas:

```bash
npm run build
npx cap sync android
cd android
./gradlew assembleDebug
```

No Windows PowerShell, use `gradlew.bat assembleDebug`.

## Observações sobre áudio

- Para URLs remotas, use um link direto para um arquivo/stream de áudio, não uma página HTML de YouTube, Spotify ou outro site.
- O servidor remoto precisa permitir acesso pelo WebView e, quando aplicável, CORS. HTTPS é recomendado.
- A implementação atual usa o elemento HTML5 Audio para URLs e arquivos locais. O helper `src/services/audio.ts` também inclui suporte experimental a `ReadableStream` por MediaSource Extensions; o MIME e codecs precisam ser aceitos pelo WebView Android.
- Arquivos locais são selecionados pelo seletor do Android. A fila atual é mantida em memória e é perdida ao fechar o app.
- Letras dependem da disponibilidade e correspondência dos metadados no LRCLIB e de conexão com a internet. O app não baixa nem armazena cópias de letras.
- A API pública LRCLIB pode alterar limites ou disponibilidade. Consulte a documentação oficial antes de publicar em larga escala.

## Estrutura

```text
OryX/
├── public/
│   └── oryx-logo.svg
├── src/
│   ├── services/
│   │   ├── audio.ts
│   │   └── lrclib.ts
│   ├── App.tsx
│   ├── main.tsx
│   ├── styles.css
│   └── types.ts
├── capacitor.config.ts
├── package.json
└── README.md
```

## Próximas melhorias recomendadas

- Persistir playlists e favoritos com Preferences/SQLite.
- Ler tags ID3 para extrair artista, álbum e capa automaticamente.
- Controles na tela bloqueada e notificações com Media Session / plugin nativo.
- Reprodução em segundo plano com serviço Android nativo.
- Busca LRCLIB por `/api/search` como fallback quando `/api/get` não encontrar correspondência.
- Tratamento de URLs com autenticação, playlists e formatos de streaming adaptativos.
