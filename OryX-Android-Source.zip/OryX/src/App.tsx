import { useEffect, useMemo, useRef, useState } from "react";
import {
  AudioLines, Disc3, FileAudio, Heart, ListMusic,
  LoaderCircle, Music2, Pause, Play, Plus, Search, SkipBack,
  SkipForward, Volume2, X
} from "lucide-react";
import { loadAudio } from "./services/audio";
import { findLyrics, parseSyncedLyrics, type LyricLine } from "./services/lrclib";
import type { LyricsResult, Track } from "./types";

const formatTime = (value: number) => {
  if (!Number.isFinite(value)) return "0:00";
  const minutes = Math.floor(value / 60);
  const seconds = Math.floor(value % 60).toString().padStart(2, "0");
  return `${minutes}:${seconds}`;
};

const makeTrack = (file: File): Track => ({
  id: `${file.name}-${file.lastModified}-${file.size}`,
  title: file.name.replace(/\.[^.]+$/, ""),
  artist: "Arquivo local",
  src: URL.createObjectURL(file),
  kind: "local",
  file
});

export default function App() {
  const audioRef = useRef<HTMLAudioElement>(null);
  const cleanupRef = useRef<(() => void) | null>(null);
  const tracksRef = useRef<Track[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [tracks, setTracks] = useState<Track[]>([]);
  const [current, setCurrent] = useState<Track | null>(null);
  const [playing, setPlaying] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(0.85);
  const [url, setUrl] = useState("");
  const [lyrics, setLyrics] = useState<LyricsResult | null>(null);
  const [lyricsBusy, setLyricsBusy] = useState(false);
  const [lyricsError, setLyricsError] = useState("");
  const [lyricsTrack, setLyricsTrack] = useState("");
  const [lyricsArtist, setLyricsArtist] = useState("");
  const [activeLyric, setActiveLyric] = useState(0);
  const [liked, setLiked] = useState<string[]>([]);
  const [tab, setTab] = useState<"lyrics" | "queue">("lyrics");

  const lyricLines: LyricLine[] = useMemo(
    () => parseSyncedLyrics(lyrics?.syncedLyrics ?? null),
    [lyrics]
  );

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    audio.volume = volume;
  }, [volume]);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    const update = () => setCurrentTime(audio.currentTime || 0);
    const meta = () => setDuration(audio.duration || 0);
    audio.addEventListener("timeupdate", update);
    audio.addEventListener("loadedmetadata", meta);
    return () => {
      audio.removeEventListener("timeupdate", update);
      audio.removeEventListener("loadedmetadata", meta);
      cleanupRef.current?.();
    };
  }, []);

  useEffect(() => {
    if (!lyricLines.length) return;
    let index = 0;
    for (let i = 0; i < lyricLines.length; i++) {
      if (lyricLines[i].time <= currentTime) index = i;
      else break;
    }
    setActiveLyric(index);
  }, [currentTime, lyricLines]);

  useEffect(() => {
    tracksRef.current = tracks;
  }, [tracks]);

  useEffect(() => {
    return () => {
      cleanupRef.current?.();
      tracksRef.current.forEach(track => {
        if (track.kind === "local") URL.revokeObjectURL(track.src);
      });
    };
  }, []);

  async function playTrack(track: Track) {
    const audio = audioRef.current;
    if (!audio) return;
    cleanupRef.current?.();
    cleanupRef.current = null;
    setError("");
    setLoading(true);
    setPlaying(false);
    setCurrent(track);
    setLyrics(null);
    setLyricsError("");
    setLyricsTrack(track.title);
    setLyricsArtist(track.artist === "Arquivo local" || track.artist === "Streaming online" ? "" : track.artist);
    setCurrentTime(0);
    setDuration(0);

    try {
      const cleanup = await loadAudio(audio, track.src, {
        onCanPlay: () => setLoading(false),
        onWaiting: () => setLoading(true),
        onEnded: () => setPlaying(false),
        onError: err => { setError(err.message); setLoading(false); setPlaying(false); }
      });
      cleanupRef.current = cleanup;
      await audio.play();
      setPlaying(true);
      setLoading(false);
      void loadTrackLyrics(track, audio);
    } catch (cause) {
      setLoading(false);
      setError(cause instanceof Error ? cause.message : "Erro ao reproduzir.");
    }
  }

  async function loadTrackLyrics(track: Track, audio: HTMLAudioElement) {
    await searchLyrics(track.title, track.artist === "Arquivo local" || track.artist === "Streaming online" ? "" : track.artist,
      Number.isFinite(audio.duration) ? audio.duration : undefined);
  }

  async function searchLyrics(trackName = lyricsTrack, artistName = lyricsArtist, trackDuration?: number) {
    if (!trackName.trim()) {
      setLyricsError("Informe o nome da música para buscar as letras.");
      return;
    }
    setLyricsBusy(true);
    setLyricsError("");
    try {
      const result = await findLyrics(trackName.trim(), artistName.trim(), trackDuration);
      setLyrics(result);
      if (!result) setLyricsError("Nenhuma letra encontrada. Confira o título e o artista.");
    } catch (cause) {
      setLyricsError(cause instanceof Error ? cause.message : "Erro ao buscar letras.");
    } finally {
      setLyricsBusy(false);
    }
  }

  async function togglePlay() {
    const audio = audioRef.current;
    if (!audio) return;
    if (!current) {
      if (tracks[0]) await playTrack(tracks[0]);
      return;
    }
    if (audio.paused) {
      try { await audio.play(); setPlaying(true); }
      catch { setError("Toque em reproduzir novamente para iniciar o áudio."); }
    } else {
      audio.pause();
      setPlaying(false);
    }
  }

  function addFiles(files: FileList | null) {
    if (!files) return;
    const accepted = Array.from(files)
      .filter(file => file.type.startsWith("audio/"))
      .map(makeTrack);
    setTracks(previous => [...previous, ...accepted]);
    if (!current && accepted[0]) void playTrack(accepted[0]);
  }

  function addUrl() {
    const value = url.trim();
    if (!/^https?:\/\//i.test(value)) {
      setError("Informe uma URL de áudio iniciada por http:// ou https://.");
      return;
    }
    const track: Track = {
      id: `url-${Date.now()}`,
      title: decodeURIComponent(value.split("/").pop()?.split("?")[0] || "Stream online"),
      artist: "Streaming online",
      src: value,
      kind: "url"
    };
    setTracks(previous => [...previous, track]);
    setUrl("");
    void playTrack(track);
  }

  function stepTrack(direction: number) {
    if (!tracks.length) return;
    const index = current ? tracks.findIndex(track => track.id === current.id) : -1;
    const next = (index + direction + tracks.length) % tracks.length;
    void playTrack(tracks[next]);
  }

  function seek(value: number) {
    if (audioRef.current) audioRef.current.currentTime = value;
    setCurrentTime(value);
  }

  function toggleLike() {
    if (!current) return;
    setLiked(previous => previous.includes(current.id)
      ? previous.filter(id => id !== current.id)
      : [...previous, current.id]);
  }

  const isLiked = current ? liked.includes(current.id) : false;

  return (
    <main className="app-shell">
      <audio ref={audioRef} preload="metadata" />
      <header className="topbar">
        <img src="/oryx-logo.svg" className="logo" alt="OryX" />
        <span className="topbar-label">MUSIC PLAYER</span>
        <button className="icon-button" aria-label="Abrir biblioteca"
          onClick={() => fileInputRef.current?.click()}><Plus size={21} /></button>
        <input ref={fileInputRef} type="file" accept="audio/*" multiple hidden
          onChange={event => addFiles(event.target.files)} />
      </header>

      <section className="welcome">
        <div>
          <p className="eyebrow">SEU SOM. SEU MOMENTO.</p>
          <h1>Ouça do seu <span>jeito.</span></h1>
          <p className="subtext">Sua música, suas letras, seu OryX.</p>
        </div>
        <div className="orb"><AudioLines size={35} /></div>
      </section>

      <section className="source-card">
        <div className="section-heading"><span><Music2 size={17} /> ADICIONAR MÚSICA</span></div>
        <button className="local-button" onClick={() => fileInputRef.current?.click()}>
          <FileAudio size={19} />
          <span><strong>Escolher arquivos locais</strong><small>MP3, M4A, WAV e formatos compatíveis</small></span>
          <Plus size={19} className="push" />
        </button>
        <div className="url-row">
          <input value={url} onChange={event => setUrl(event.target.value)}
            onKeyDown={event => { if (event.key === "Enter") addUrl(); }}
            placeholder="Cole a URL direta do áudio..." aria-label="URL do áudio" />
          <button onClick={addUrl} aria-label="Reproduzir URL"><Play size={18} /></button>
        </div>
      </section>

      <section className="player-card">
        <div className="cover">
          <div className="cover-glow" />
          <Disc3 size={86} strokeWidth={1.1} />
          <span>ORYX</span>
        </div>
        <div className="track-info">
          <div className="track-copy">
            <p className="eyebrow">TOCANDO AGORA</p>
            <h2>{current?.title ?? "Escolha uma música"}</h2>
            <p>{current?.artist ?? "Sua biblioteca está esperando"}</p>
          </div>
          <button className={`like-button ${isLiked ? "liked" : ""}`} onClick={toggleLike}
            aria-label="Favoritar música" disabled={!current}><Heart size={21} fill={isLiked ? "currentColor" : "none"} /></button>
        </div>
        <div className="timeline">
          <input type="range" min={0} max={duration || 1} step={0.1}
            value={Math.min(currentTime, duration || 1)}
            onChange={event => seek(Number(event.target.value))} aria-label="Posição da música" />
          <div className="time-labels"><span>{formatTime(currentTime)}</span><span>{formatTime(duration)}</span></div>
        </div>
        <div className="controls">
          <button className="control-muted" onClick={() => stepTrack(-1)} aria-label="Anterior"><SkipBack /></button>
          <button className="play-button" onClick={() => void togglePlay()} aria-label={playing ? "Pausar" : "Reproduzir"}>
            {loading ? <LoaderCircle className="spin" /> : playing ? <Pause fill="currentColor" /> : <Play fill="currentColor" />}
          </button>
          <button className="control-muted" onClick={() => stepTrack(1)} aria-label="Próxima"><SkipForward /></button>
        </div>
        <div className="volume-row"><Volume2 size={16} /><input type="range" min={0} max={1} step={0.01}
          value={volume} onChange={event => setVolume(Number(event.target.value))} aria-label="Volume" /></div>
        {error && <p className="error-message"><X size={14} /> {error}</p>}
      </section>

      <section className="lower-card">
        <div className="tabs">
          <button className={tab === "lyrics" ? "active" : ""} onClick={() => setTab("lyrics")}><AudioLines size={16} /> LETRAS</button>
          <button className={tab === "queue" ? "active" : ""} onClick={() => setTab("queue")}><ListMusic size={16} /> FILA ({tracks.length})</button>
        </div>
        {tab === "lyrics" ? (
          <div className="lyrics-panel">
            <div className="lyrics-search">
              <input value={lyricsTrack} onChange={event => setLyricsTrack(event.target.value)}
                placeholder="Nome da música" aria-label="Nome da música" />
              <input value={lyricsArtist} onChange={event => setLyricsArtist(event.target.value)}
                placeholder="Artista (opcional)" aria-label="Artista" />
              <button onClick={() => void searchLyrics()} disabled={lyricsBusy} aria-label="Buscar letras">
                {lyricsBusy ? <LoaderCircle className="spin" size={17} /> : <Search size={17} />}
              </button>
            </div>
            {lyricsBusy ? <div className="empty-state"><LoaderCircle className="spin" /> Buscando letras no LRCLIB...</div>
              : lyricLines.length ? <div className="lyric-lines">
                {lyricLines.map((line, index) => <p key={`${line.time}-${index}`}
                  className={index === activeLyric ? "current-line" : ""}
                  onClick={() => seek(line.time)}>{line.text || "♪"}</p>)}
              </div>
              : lyrics?.plainLyrics ? <p className="plain-lyrics">{lyrics.plainLyrics}</p>
              : <div className="empty-state"><AudioLines size={28} />
                <strong>{lyricsError || "As letras aparecerão aqui"}</strong>
                <span>Reproduza uma faixa para procurar letras sincronizadas.</span>
              </div>}
          </div>
        ) : (
          <div className="queue-list">
            {tracks.length === 0 ? <div className="empty-state"><Music2 size={28} /><strong>Nenhuma música adicionada</strong><span>Adicione arquivos ou uma URL acima.</span></div>
              : tracks.map(track => <button className={`queue-item ${current?.id === track.id ? "selected" : ""}`}
                key={track.id} onClick={() => void playTrack(track)}>
                <span className="queue-icon"><Music2 size={17} /></span>
                <span className="queue-copy"><strong>{track.title}</strong><small>{track.artist}</small></span>
                {current?.id === track.id && playing ? <AudioLines size={18} className="red-icon" /> : <Play size={16} />}
              </button>)}
          </div>
        )}
      </section>
      <footer><span>ORY<span className="red">X</span></span><small>FEITO PARA SENTIR A MÚSICA.</small></footer>
    </main>
  );
}
